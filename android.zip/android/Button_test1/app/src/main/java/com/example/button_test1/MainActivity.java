package com.example.button_test1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.button_test1.service.WebService;

public class MainActivity extends AppCompatActivity {

    private WebService webService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webService = WebService.getInstance(MainActivity.this);

        Button button1 = findViewById(R.id.button);
        final EditText EdTxtName = findViewById(R.id.EdTxtName);
        final EditText EdTxtPswd = findViewById(R.id.EdTxtPswd);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = EdTxtName.getText().toString();
                String password = EdTxtPswd.getText().toString();
                String msg = webService.remoteLogin(username,password);
                System.out.println("----------"+msg);
                if (msg == "fails" || msg == null)
                {
                    System.out.println("fail");
                    String failmsg = "Votre nom ou le mot de passe n'est pas correct";
                    Toast.makeText(MainActivity.this, failmsg,Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent userPage = new Intent(MainActivity.this,UserPage.class);
                    userPage.putExtra("userInfo",msg);
                    startActivity(userPage);
                }


            }
        });

    }

}
