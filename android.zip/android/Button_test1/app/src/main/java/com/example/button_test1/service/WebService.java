package com.example.button_test1.service;

import android.content.Context;
import android.net.http.AndroidHttpClient;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class WebService {

    private static final String LOGIN_URL = "http://192.168.1.6:8080/login";
    private RequestQueue queue;
    private String result;
    public static WebService instance = null;

    private WebService(Context context)
    {
        queue = Volley.newRequestQueue(context.getApplicationContext());
    }

    public static WebService getInstance(Context context)
    {
        if (instance == null)
        {
            instance = new WebService(context);
        }
        return instance;
    }

    public String remoteLogin(String username,String password)
    {
        String url = LOGIN_URL + "?username=" +username +"&password="+password;
//        String url2 = "http://www.google.com";
        String url2 = "http://192.168.1.6:8080/login?username="+username+"&password="+password;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                System.out.println(response);
                if (response.equals("fail"))
                    result = "fail";
                else
                    result = response.toString();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Error: "+error.getMessage());
                result = "fail";
            }
        });
        queue.add(stringRequest);
        return result;
    }

}





















