package com.example.button_test1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.button_test1.modules.User;

import org.json.JSONObject;

public class UserPage extends AppCompatActivity {

    private TextView txtUsername;
    private User user;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_page);
        Intent intent = getIntent();
        user = new User();
        try {
            JSONObject jsonObject = new JSONObject(intent.getStringExtra("userInfo"));
            user.setUsername(jsonObject.getString("username"));
            user.setUser_id(jsonObject.getInt("user_id"));
            user.setEmail(jsonObject.getString("email"));
            user.setPhone(jsonObject.getString("phone"));
            System.out.println(user);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        txtUsername = (TextView) findViewById(R.id.txtUsername);
        String username = user.getUsername();
        txtUsername.setText("Hello, "+username);

    }

}
