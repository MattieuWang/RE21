package com.example.button_test1.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;

public class WebUtils {

    public String getWebResponse(HttpURLConnection connection)
    {
        BufferedReader reader = null;
        InputStream inputStream = null;
        String response = "";
        try {
            inputStream = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine())!= null)
            {
                builder.append(line);
            }
            response = builder.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

}
