package com.example.button_test1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.example.button_test1.modules.User;
import com.example.button_test1.service.WebService;
import com.example.button_test1.service.WebUtils;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private WebService webService;
    private Button btnLogin;
    private EditText edTxtName;
    private EditText edTxtPswd;

    private WebUtils utils;

    private User user;
    private String username;
    private String password;
    private final static String BASE_URL = "http://192.168.43.6:8080/re21-v1/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webService = WebService.getInstance(MainActivity.this);
        user = new User();
        utils = new WebUtils();
        btnLogin = findViewById(R.id.btnLogin);
        edTxtName = findViewById(R.id.EdTxtName);
        edTxtPswd = findViewById(R.id.EdTxtPswd);

        final Handler handler = new Handler()
        {
            @Override
            public void handleMessage(@NonNull Message msg) {
                switch (msg.what)
                {
                    case 0:
                        String failmsg = "Votre nom ou le mot de passe n'est pas correct";
                        Toast.makeText(MainActivity.this, failmsg,Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        Intent userPage = new Intent(MainActivity.this,UserPage.class);
                        userPage.putExtra("userInfo",(String) msg.obj);
                        startActivity(userPage);
                        break;

                }
            }
        };

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username = edTxtName.getText().toString();
                password = edTxtPswd.getText().toString();
                new Thread()
                {
                    @Override
                    public void run() {
                        BufferedReader reader = null;
                        InputStream inputStream = null;
                        String strurl = BASE_URL + "login?username="+username+"&password="+password;
                        // http://192.168.43.6:8080/re21-v1/login?
                        try {
                            URL url = new URL(strurl);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("POST");    //"GET"
                            connection.setRequestProperty("Content-Type", "application/json");
                            connection.connect();

                            String response;        // JSON  {"key":"value","key1":["1","2"]}
                            inputStream = connection.getInputStream();
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            StringBuilder builder = new StringBuilder();
                            String line;
                            while ((line = reader.readLine())!= null)
                            {
                                System.out.println("line:"+line);
                                builder.append(line);
                            }
                            response = builder.toString();
                            System.out.println(response);
                            Message message = Message.obtain();
                            if (response.equals("fail") || response.equals(""))
                            {
                                message.what = 0;
                            }
                            else
                            {
                                message.what = 1;
                                message.obj = response;
                            }
                            handler.sendMessage(message);

                        } catch (FileNotFoundException e) {
                            Message message = Message.obtain();
                            message.what = 0;
                            handler.sendMessage(message);
                            e.printStackTrace();
                        } catch (ProtocolException e) {
                            e.printStackTrace();
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });
    }

}
