package com.example.button_test1.service;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Base64;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class WebService {

    private static final String BASE_URL = "http://192.168.1.6:8080/re21-v1/";
    private RequestQueue queue;
    private String result = "";
    public static WebService instance = null;

    private WebService(Context context)
    {
        queue = Volley.newRequestQueue(context.getApplicationContext());
    }

    public static WebService getInstance(Context context)
    {
        if (instance == null)
        {
            instance = new WebService(context);
        }
        return instance;
    }

    public String remoteLogin(String username,String password)
    {
        String url = BASE_URL + "login?username=" +username +"&password="+password;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                System.out.println("response: " + response);
                if (response.equals("fail"))
                    result = "fail";
                else
                    result = response;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Error: " + error.getMessage());
                result = "fail";
            }
        });
        System.out.println("==========results: "+result);
        queue.add(stringRequest);

        return result;
    }

    public String getURLRequest(String strurl) {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        String response = "";
        try {
            URL url = new URL(strurl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            if (connection.getResponseCode() == 200)
            {
                System.out.println("etat: reussir");
            }
            InputStream inputStream = connection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            while (reader.readLine()!=null) {
                response += reader.readLine();
                System.out.println("response:" + response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(response);
        return response;
    }

    public Bitmap receiveImage()
    {
        String url = BASE_URL + "rest.PNG";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                System.out.println("response: " + response);
                if (response.equals("fail"))
                    result = "fail";
                else
                    result = response;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Error: " + error.getMessage());
                result = "fail";
            }
        });
        Bitmap bitmap = null;
        byte[] bytes = Base64.decode(result,Base64.URL_SAFE);
        bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
        return bitmap;

    }


}





















