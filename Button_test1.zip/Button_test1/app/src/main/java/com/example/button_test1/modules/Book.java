package com.example.button_test1.modules;

import java.util.ArrayList;

public class Book {
    private String book_name;
    private String book_desc;
    private Integer book_id;
    private Integer book_num;
    private ArrayList<String> image_location;  // 以 , 分割每个图片位置
    private String tags;    // 书籍所属分类   以 , 分割
    private boolean hasDone;  // 是否已被交易 default is false

    public Book() {
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getBook_desc() {
        return book_desc;
    }

    public void setBook_desc(String book_desc) {
        this.book_desc = book_desc;
    }

    public Integer getBook_id() {
        return book_id;
    }

    public void setBook_id(Integer book_id) {
        this.book_id = book_id;
    }

    public Integer getBook_num() {
        return book_num;
    }

    public void setBook_num(int book_num) {
        this.book_num = book_num;
    }

    public ArrayList<String> getImage_location() {
        return image_location;
    }

    public void setImage_location(ArrayList<String> image_location) {
        this.image_location = image_location;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public boolean isHasDone() {
        return hasDone;
    }

    public void setHasDone(boolean hasDone) {
        this.hasDone = hasDone;
    }
}
