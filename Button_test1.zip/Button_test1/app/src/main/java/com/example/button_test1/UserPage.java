package com.example.button_test1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.toolbox.ImageLoader;
import com.example.button_test1.modules.Book;
import com.example.button_test1.modules.User;
import com.example.button_test1.service.WebService;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class UserPage extends AppCompatActivity {

    private TextView txtUsername;
    private User user;
    private ImageView imageView;
    private WebService webService;
    private Button buttonTest;
    private TextView txtBookName;
    private TextView txtOwner;
    private TextView txtNum;
    private TextView txtDesc;
    private ArrayList<Book> books;
    Bitmap bitmap;
    String BASE_URL = "http://192.168.43.6:8080/re21-v1/";


    private  Handler handler = new Handler()
    {
        @Override
        public void handleMessage(@NonNull Message msg) {
            switch (msg.what)
            {
                case 1:
                    imageView.setImageBitmap((Bitmap) msg.obj);
                    break;
                case 2:
                    for (Book book : books)
                    {
                        txtBookName.setText("Nom de livre: "+book.getBook_name());
                        txtDesc.setText("description \n"+book.getBook_desc());
                        txtOwner.setText("propriétaire: "+user.getUsername());
                        txtNum.setText("quantité: "+book.getBook_num().toString());
                    }
            }

        }
    };


    protected void onCreate(Bundle savedInstanceState) {
        webService = WebService.getInstance(UserPage.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_page);
        imageView = findViewById(R.id.imageViewTest);
        buttonTest = findViewById(R.id.buttonTest);
        txtUsername = findViewById(R.id.txtUsername);
        txtBookName = findViewById(R.id.txtBookName);
        txtNum = findViewById(R.id.txtNum);
        txtDesc = findViewById(R.id.txtDesc);
        txtOwner = findViewById(R.id.txtOwner);
        final Intent intent = getIntent();
        user = new User();
        books = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(intent.getStringExtra("userInfo"));
            JSONObject jsonObject1 = new JSONObject(jsonObject.getString("msg"));
            user.setUsername(jsonObject1.getString("username"));
            user.setUser_id(jsonObject1.getInt("user_id"));
            user.setEmail(jsonObject1.getString("email"));
            user.setPhone(jsonObject1.getString("phone"));
            System.out.println(user);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        final String username = user.getUsername();
        txtUsername.setText("Hello, "+username);



        buttonTest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread()
                {
                    @Override
                    public void run() {
                        String requestUrl = BASE_URL + "and/getuserbooks/" + user.getUser_id();
                        try {
                            URL url = new URL(requestUrl);
                            BufferedReader reader = null;
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("GET");
                            InputStream inputStream = connection.getInputStream();
                            reader = new BufferedReader(new InputStreamReader(inputStream));
                            StringBuilder builder = new StringBuilder();
                            String line;
                            while ((line = reader.readLine())!= null)
                            {
                                builder.append(line);
                            }
                            String response = builder.toString();
                            System.out.println(response);
                            JSONObject jsonObject = new JSONObject(response);
                            int size = jsonObject.getInt("size");
                            for (int i = 0; i < size; i++) {
                                JSONObject tmp = new JSONObject(jsonObject.getString("book"+i));
                                Book book = new Book();
                                book.setBook_name(tmp.getString("book_name"));
                                book.setBook_id(tmp.getInt("book_id"));
                                book.setBook_desc(tmp.getString("book_desc"));
                                book.setBook_num(tmp.getInt("book_num"));
                                book.setHasDone(tmp.getBoolean("hasDone"));
                                ArrayList<String> imageLocation = new ArrayList<>();
                                JSONArray imageArray = tmp.getJSONArray("image_location");
                                // {"image":["","",""]} .png
                                for (int j = 0; j < imageArray.length(); j++) {
                                    imageLocation.add(imageArray.getString(j));
                                }
                                book.setImage_location(imageLocation);
                                books.add(book);

                                Message message = Message.obtain();
                                message.what = 2;
                                handler.sendMessage(message);

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            Book book = books.get(books.size()-1);
                            String strUrl = book.getImage_location().get(0);
                            URL url = new URL(strUrl);
                            InputStream inputStream = url.openStream();
                            bitmap = BitmapFactory.decodeStream(inputStream);
                            inputStream.close();
                            Message message = Message.obtain();
                            message.obj = bitmap;
                            message.what = 1;
                            handler.sendMessage(message);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });



    }


}
